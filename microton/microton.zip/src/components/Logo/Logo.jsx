import "./Logo.scss";
export default () => {
  return (
    <div className='logo'>
      <div>МИКРО</div>
      <div>ТОН.</div>
      <small>Recipe editor</small>
    </div>
  );
};
